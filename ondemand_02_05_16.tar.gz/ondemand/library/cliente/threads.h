#ifndef THREADS_h
#define THREADS_H

#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>

char mensagem[128];
int global;
void *ler_teclado();

#endif
