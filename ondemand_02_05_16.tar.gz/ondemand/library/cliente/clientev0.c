#include "threads.h"
#include "psiskv.h"


int main(){
	pthread_t thread_teclado;
	int teclas;
	
	teclas = pthread_create(&thread_teclado,NULL,ler_teclado,NULL);
	if(teclas){
		puts("deu erro");
		exit(-1);
	}
	while(1){
		if(global==1)
			break;
	}		

	pthread_join(teclas,NULL);




	exit(1);
}
