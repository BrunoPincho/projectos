#include "threads.h"

void *ler_teclado(){

	puts("a ler do teclado\n");
	while(fgets(mensagem,128,stdin)!=NULL){

		printf("\nfoi escrito: %s \n",mensagem);
		if(strncmp(mensagem,"exit",4)==0){
			global = 1;
			pthread_exit(NULL);			
			}
	}	
	return NULL;
}
