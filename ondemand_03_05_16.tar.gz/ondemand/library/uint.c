#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <string.h>

int main(){

uint32_t x,y;
x=32;
y=69;
/*
char *string;
char *string2;
string=(char *)malloc((5)*sizeof(char));
//sprintf(string,"%u",x);
string2="ola";
strcat(string,string2);
printf("%s %s\n",string,string2);
*/

	char *mensagem;
	char *chave;
	char *tamanho;
	//sprintf(chave,"%u",x);
	chave="ola";
	sprintf(tamanho,"%u%c%s%c%u",x,'-',chave,'-',y);
	mensagem=(char *)malloc((strlen(tamanho)+3)*sizeof(char));
	strcat(mensagem,"K");
	strcat(mensagem,"-");
	strcat(mensagem,tamanho);
	strcat(mensagem,"\0");

printf("%s\t",mensagem);
free(mensagem);
exit(0);

}
