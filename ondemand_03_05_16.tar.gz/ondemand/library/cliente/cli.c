#include "psiskv.h"

int main(){
	int socket;
	int port;
	uint32_t key;
	uint32_t length;
	printf("porta?\n");
	scanf("%d",&port);
	
	socket=kv_connect("127.0.1.1",port);
	
	
	printf("socket : %d\n",socket);
	
	write(socket,"hello\n",7);
	
	key=16;
	length=6;
	
	kv_write(socket,key,"adeus",length,0);
	
	exit(0);
}
